// MyStaticDlg.h : header file
//

#if !defined(AFX_MYSTATICDLG_H__E3625259_1439_4AE0_A91F_600E1E50509B__INCLUDED_)
#define AFX_MYSTATICDLG_H__E3625259_1439_4AE0_A91F_600E1E50509B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CMyStaticDlg dialog

class CMyStaticDlg : public CDialog
{
private:
	void settext();
	void OnLoadddbpic(); 
	void getNation(int code,char *pcNationStr);
	//void ProcessMessages(); 

// Construction
public:
	CMyStaticDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CMyStaticDlg)
	enum { IDD = IDD_MYSTATIC_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyStaticDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	CStatic m_name;
    CStatic m_sex;
	CStatic m_nation;
    CStatic m_birth;
	CStatic m_idcode;
	CStatic m_addr;
	CStatic m_depart;
	CStatic m_valid;

    CBitmap  m_bmp;	
	//CRect rect;
	// Generated message map functions
	//{{AFX_MSG(CMyStaticDlg)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();	
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYSTATICDLG_H__E3625259_1439_4AE0_A91F_600E1E50509B__INCLUDED_)
